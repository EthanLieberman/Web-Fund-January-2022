function vanish(){
    // document.getElementById('#cooky')
    console.log(cooky)

    cooky.remove()
}




var succ = document.querySelector('#succ')

function replace(){
    succ.src = "./assets/succulents-2.jpg"
}

function unplace(){
    succ.src = "./assets/succulents-1.jpg"
    
}
